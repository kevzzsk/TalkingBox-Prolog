PositiveExclaim1={
    'I thought so! '
    'Wow! '
    'Oh nice! '
    'Do you! '
    'I knew it! '
    'And: '
    'Good! '
    };
Question={
    'May be you like '
    'How about '
    'Do you like '
    'Let me guess, you like '
    'I imagine you like '
    };
PositiveExclaim2={
    ' also?'
    ' too?'
    '?'
    };
NegativeExclaim1={
    'Ok! '
    'Oh! '
    'Hmmm! '
    'Nevermind! '
    'Well! '
    'Let''s see: '
    };
NegativeExclaim2={
    ', may be?'
    '?'
    ', I hope?'
    };
    